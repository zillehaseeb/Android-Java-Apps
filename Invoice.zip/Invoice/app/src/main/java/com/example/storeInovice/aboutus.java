package com.example.storeInovice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class aboutus extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aboutus);

    }


}
